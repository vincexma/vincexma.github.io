using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StairsToBowRoom : MonoBehaviour
{
    public GameObject mainCam;
    ArrowKeyMovement akm;
    
    // Start is called before the first frame update
    void Start()
    {
        akm = GetComponent<ArrowKeyMovement>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("stairs") && gameObject.tag == "Player")
        {
            akm.state = ArrowKeyMovement.InputAllowed.BOWROOM;
            Debug.Log("going downstairs");
            //TODO: find bow room tiles and send player to them on this trigger
            mainCam.transform.position = new Vector3(23.5f, 50.85f, -10);
            this.gameObject.transform.position = new Vector3(18.8f, 53.5f, 0);
        }
        if (other.CompareTag("exitStairs") && gameObject.tag == "Player")
        {
            akm.state = ArrowKeyMovement.InputAllowed.ENABLED;
            Debug.Log("going upstairs");
            //TODO: find bow room tiles and send player to them on this trigger
            mainCam.transform.position = new Vector3(23.5f, 62, -10);
            this.gameObject.transform.position = new Vector3(23, 60, 0);
        }
    }
}
