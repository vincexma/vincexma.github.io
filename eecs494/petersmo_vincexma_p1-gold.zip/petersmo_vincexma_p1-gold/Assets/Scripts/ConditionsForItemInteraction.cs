using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public delegate void InteractionSender3();

public class ConditionsForItemInteraction : MonoBehaviour
{
    Rigidbody rb;
    SpriteRenderer sr;
    BoxCollider bc;
    private int enemies_defeated;
    // bool item_freed;

    public AudioClip keyDrop;

    public static InteractionSender3 unlock_old_man; 

    int keese1 = 0;
    int keese2 = 0;
    int stalfos = 0;
    int gel = 0;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        sr = GetComponent<SpriteRenderer>();
        bc = GetComponent<BoxCollider>();
        HasHealthAndHitbox.on_enemy_defeated += DefeatEnemy;
        // HasHealthAndHitbox.on_enemy_defeated += FreeItem;
        enemies_defeated = 0;
        if (gameObject.layer == 7)
        {
            sr.enabled = false;
            bc.enabled = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (ConditionsAreMet())
        {
            if (gameObject.CompareTag("gelBlock") || gameObject.CompareTag("bowroomBlock"))
            {
                rb.constraints = RigidbodyConstraints.None;
                rb.constraints = RigidbodyConstraints.FreezePositionZ;
                rb.constraints = RigidbodyConstraints.FreezeRotation;
                if (LockPosition())
                {
                    rb.constraints = RigidbodyConstraints.FreezeAll;
                }
            }
            else if (gameObject.layer == 7)
            {
                sr.enabled = true;
                bc.enabled = true;
            }
        }
    }

    void DefeatEnemy(string enemy)
    {
        if (enemy == "keese1")
        {
            ++keese1;
        }
        if (enemy == "keese2")
        {
            ++keese2;
        }
        if (enemy == "stalfos")
        {
            ++stalfos;
        }
        if (enemy == "gel")
        {
            ++gel;
        }
        Debug.Log("Enemy defeated");
    }

    private bool ConditionsAreMet()
    {
        // for some reason DefeatEnemy is running twice per enemy, it normally should be enemies_defeated >= 3 but this is a temporary workaround
        if (gameObject.CompareTag("gelBlock") && gel >= 3)
        {
            // conditions are met when no gels remain / 3 gels have been killed in that room
            return true;
        }

        else if (gameObject.CompareTag("bowroomBlock"))
        {
            return true;
        }

        else if (gameObject.CompareTag("invisKey"))
        {
            if (stalfos >= 3 && gameObject.transform.position.x > 33.5 && gameObject.transform.position.x < 45.5 &&
                        gameObject.transform.position.y > 23.5 && gameObject.transform.position.y < 30.5)
            {
                // room 2,2 stalfos key
                return true;
            }
            else if (keese1 >= 3 && gameObject.transform.position.x > 17.5 && gameObject.transform.position.x < 29.5 &&
                        gameObject.transform.position.y > 1.5 && gameObject.transform.position.y < 8.5)
            {
                // room 1, 0 keese key
                return true;
            }
            else
            {
                return false;
            }
        }

        /* else if (gameObject.CompareTag("heldKey"))
        {
            if (item_freed)
            {
                return true;
            }
            else
            {
                return false;
            }
        } */

        else
        {
            return false;
        }
    }

    private bool LockPosition()
    {
        if (gameObject.CompareTag("gelBlock") || gameObject.CompareTag("bowroomBlock"))
        {
            // conditions are met when no gels remain / 3 gels have been killed in that room
            if (rb.transform.position.x >= 24 || rb.transform.position.x <= 22 || rb.transform.position.y >= 39 || rb.transform.position.y <= 37 && gameObject.CompareTag("gelBlock"))
            {
                if (unlock_old_man != null && gameObject.CompareTag("gelBlock"))
                {
                    unlock_old_man();
                    unlock_old_man = null;
                }
                return true;

                // at this point call the function that will unlock the old man door
            }
            else if ((rb.transform.position.x >= 23 || rb.transform.position.x <= 21 || rb.transform.position.y >= 61 || rb.transform.position.y <= 59) && gameObject.CompareTag("bowroomBlock"))
            {

                return true;
               
            }
            else { 
                return false;
            }
        }
        else
        {
            return false;
        }
    }
}
