using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public delegate void InteractionSender4(string collectable);

public class Collector : MonoBehaviour
{
    public HasHealthAndHitbox health;

    public AudioClip rupee_collection_sound_clip;
    public AudioClip heart_collection_sound_clip;
    public AudioClip key_collection_sound_clip;
    public AudioClip bomb_collection_sound_clip;
    public AudioClip bow_collection_sound_clip;
    public AudioClip boom_collection_sound_clip;

    public Sprite happySprite;
    public Sprite happySprite2;

    public static InteractionSender4 collectedItem;

    public bool boom_dropped = false;

    [SerializeField] Inventory inventory;

    bool del = false;

    void OnTriggerEnter(Collider coll)
    {
        if (inventory == null)
        {
            del = true;
        }
        
        GameObject object_collided_with = coll.gameObject;
        if (object_collided_with.tag == "rupee")
        {
            if (!del)
            {
                inventory.AddRupees(1);
            }
            else
            {
                collectedItem("rupee");
            }
            Destroy(object_collided_with);

            // play sound effect
            AudioSource.PlayClipAtPoint(rupee_collection_sound_clip, Camera.main.transform.position);
        }
        else if (object_collided_with.layer == 7 || object_collided_with.CompareTag("key"))
        {
            if (!del)
            {
                inventory.AddKeys(1);
            }
            else
            {
                collectedItem("key");
            }
            Destroy(object_collided_with);

            // play sound effect
            AudioSource.PlayClipAtPoint(key_collection_sound_clip, Camera.main.transform.position);
        }
        else if (object_collided_with.tag == "heart")
        {
            if (!del)
            {
                health.AddHealth();
            }
            else
            {
                collectedItem("health");
            }
            Destroy(object_collided_with);

            // play sound effect
            AudioSource.PlayClipAtPoint(heart_collection_sound_clip, Camera.main.transform.position);
        }
        else if (object_collided_with.tag == "boom")
        {
            AudioSource.PlayClipAtPoint(boom_collection_sound_clip, Camera.main.transform.position);
            Destroy(object_collided_with);
            ActivatedByPlayerDirectionAndKeyDown[] booms = GetComponentsInChildren<ActivatedByPlayerDirectionAndKeyDown>();
            foreach(ActivatedByPlayerDirectionAndKeyDown boom in booms)
            {
                if (boom.tag == "boom")
                {
                    boom_dropped = true;
                    boom.unlocked = true;
                }
            }
        }
        else if (object_collided_with.tag == "bombman")
        {
            
            ActivatedByPlayerDirectionAndKeyDown[] booms = GetComponentsInChildren<ActivatedByPlayerDirectionAndKeyDown>();
            foreach (ActivatedByPlayerDirectionAndKeyDown boom in booms)
            {
                if (boom.tag == "bombman")
                {
                    Debug.Log("grabbed bomberman");
                    boom.unlocked = true;
                    StartCoroutine(KeyItem("bombman", object_collided_with));
                }
            }
        }
        else if (object_collided_with.tag == "bomb")
        {
            if (!del)
            {
                inventory.AddBombs(1);
            }
            else
            {
                collectedItem("bomb");
            }

            Destroy(object_collided_with);
            
            // play sound effect
            AudioSource.PlayClipAtPoint(bomb_collection_sound_clip, Camera.main.transform.position);
        }
        else if (object_collided_with.tag == "bow")
        {
            if (!del)
            {
                StartCoroutine(KeyItem(object_collided_with.tag, object_collided_with));
                ActivatedByPlayerDirectionAndKeyDown[] booms = GetComponentsInChildren<ActivatedByPlayerDirectionAndKeyDown>();
                foreach (ActivatedByPlayerDirectionAndKeyDown bow in booms)
                {
                    if (bow.tag == "bow")
                    {
                        bow.unlocked = true;
                    }
                }
            }
            
        }
        else if (object_collided_with.tag == "triforce")
        {
            if (!del)
            {
                StartCoroutine(KeyItem(object_collided_with.tag, object_collided_with));
            }
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        if (inventory == null)
        {
            Debug.LogWarning("WARNING: Gameobject with a collector has no inventory to store things in!");
        }
    }

    IEnumerator KeyItem(string item, GameObject object_collided_with)
    {
        if (item == "triforce")
        {
            gameObject.GetComponent<ArrowKeyMovement>().state = ArrowKeyMovement.InputAllowed.DISABLED;
            gameObject.GetComponent<SpriteRenderer>().sprite = happySprite2;
            object_collided_with.GetComponent<Transform>().position = new Vector3(object_collided_with.GetComponent<Transform>().position.x,
                object_collided_with.GetComponent<Transform>().position.y + 0.5f, object_collided_with.GetComponent<Transform>().position.z);
            yield return new WaitForSeconds(5.0f);
            GameController.ResetGame();
            yield return null;
        }
        else if (item == "bow")
        {
            ActivatedByPlayerDirectionAndKeyDown bow = GetComponentInChildren<ActivatedByPlayerDirectionAndKeyDown>();
            if (bow.tag == "bow")
            {
                bow.unlocked = true;
            }
            Destroy(object_collided_with);
            AudioSource.PlayClipAtPoint(bow_collection_sound_clip, Camera.main.transform.position);
            gameObject.GetComponent<ArrowKeyMovement>().state = ArrowKeyMovement.InputAllowed.DISABLED;
            gameObject.GetComponent<Animator>().enabled = false;
            gameObject.GetComponent<SpriteRenderer>().sprite = happySprite;
            yield return new WaitForSeconds(2.5f);
            gameObject.GetComponent<Animator>().enabled = true;
            gameObject.GetComponent<ArrowKeyMovement>().state = ArrowKeyMovement.InputAllowed.BOWROOM;
            yield return null;
        }
        else if (item == "bombman")
        {
            yield return new WaitForSeconds(0.1f);
            Destroy(object_collided_with);
            AudioSource.PlayClipAtPoint(bow_collection_sound_clip, Camera.main.transform.position);
            gameObject.GetComponent<ArrowKeyMovement>().state = ArrowKeyMovement.InputAllowed.DISABLED;
            gameObject.GetComponent<Animator>().enabled = false;
            gameObject.GetComponent<SpriteRenderer>().sprite = happySprite;
            yield return new WaitForSeconds(2.5f);
            gameObject.GetComponent<Animator>().enabled = true;
            gameObject.GetComponent<ArrowKeyMovement>().state = ArrowKeyMovement.InputAllowed.ENABLED;
            yield return null;
        }
        else {
            yield return null;
        }

    }
}
