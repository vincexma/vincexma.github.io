using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialLockedDoors : MonoBehaviour
{
    int enemiesDefeated;
    public bool oldMan;
    BoxCollider bc;

    public AudioClip open_old_man;

    private void Start()
    {
        bc = GetComponent<BoxCollider>();
        if (this.gameObject.CompareTag("keeselockedRoom"))
        {
            bc.isTrigger = true;
            this.gameObject.GetComponent<SpriteRenderer>().enabled = false;
        }
        else if (this.gameObject.CompareTag("oldmanRoom"))
        {
            bc.isTrigger = false;
            this.gameObject.GetComponent<SpriteRenderer>().enabled = true;
            oldMan = false;
        }
        enemiesDefeated = 0;
        HasHurtBox.on_enemy_defeated += defeatKeeseInLockedRoom;
        ConditionsForItemInteraction.unlock_old_man += unlockOldMan;
    }
    private void Update()
    {
        if (enemiesDefeated >= 6 && this.gameObject.CompareTag("keeselockedRoom")) 
        {
            bc.isTrigger = true;
            this.gameObject.GetComponent<SpriteRenderer>().enabled = false;
        }
        if (oldMan && this.gameObject.CompareTag("oldmanRoom"))
        {
            oldMan = false;
            bc.isTrigger = true;
            this.gameObject.GetComponent<SpriteRenderer>().enabled = false;
            AudioSource.PlayClipAtPoint(open_old_man, Camera.main.transform.position);
        }
    }

    void defeatKeeseInLockedRoom(string enemy)
    {
        Debug.Log("enemy defeated");
        if (enemy == "keese2")
        {
            ++enemiesDefeated;
        }
        
    }

    void unlockOldMan()
    {
        oldMan = true;
    }

    private void OnTriggerExit(Collider other)
    {
        GameObject trigger = other.gameObject;
        if (other.CompareTag("Player") && other.transform.position.x < 29.5 && this.gameObject.CompareTag("keeselockedRoom"))
        {
            bc.isTrigger = false;
            this.gameObject.GetComponent<SpriteRenderer>().enabled = true;
        }
    }
}
