using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponAttack : MonoBehaviour
{
    Rigidbody rb;
    Rigidbody parent;
    ArrowKeyMovement akm;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        parent = GetComponentInParent<Rigidbody>();
        akm = GetComponentInParent<ArrowKeyMovement>();
    }

    // Update is called once per frame
    void Update()
    {
        rb.position = parent.position;
    }

    public void doAttack(ArrowKeyMovement.InputAllowed inputType)
    {
        // weapon will contain the weapon type which will be used to determine what happens in this function
        if (inputType == ArrowKeyMovement.InputAllowed.GORIYA)
        {
            StartCoroutine(throwBoomerang());
        }
    }

    IEnumerator throwBoomerang()
    {
        rb.position = parent.position;
        Vector3 speed = akm.faceDirection * 4;
        rb.velocity = speed;
        float time = 0.0f;
        char direction = 'z';
        yield return new WaitForSeconds(0.5f);
        while (rb.velocity.x > 0.0f || rb.velocity.y > 0.0f)
        {
            time += Time.fixedDeltaTime;
            if (rb.velocity.x == 0)
            {
                rb.velocity = new Vector3(0, rb.velocity.y - (time * .01f), 0);
                direction = 'y';
            }
            else
            {

                rb.velocity = new Vector3(rb.velocity.x - (time * .01f), 0, 0);
                direction = 'x';
            }
        }
        time = 0.0f;
        while (rb.velocity.x >= speed.x * -4 && rb.velocity.y >= speed.y * -4)
        {
            time += Time.fixedDeltaTime;
            if (direction == 'y')
            {
                rb.velocity = new Vector3(0, -1 * (rb.velocity.y + (time * .01f)), 0);
            }
            else
            {
                rb.velocity = new Vector3(-1 * (rb.velocity.x + (time * .01f)), 0, 0);
            }
        }
        yield return new WaitForSeconds(0.5f);
        rb.position = parent.position;

        yield return null;
        
    }
}
