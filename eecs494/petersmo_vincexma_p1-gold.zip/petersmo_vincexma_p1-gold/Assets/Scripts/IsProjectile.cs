using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IsProjectile : MonoBehaviour
{
    [SerializeField] float speed = 10.0f;
    [SerializeField] float x_move = 0.0f;
    [SerializeField] float y_move = 0.0f;
    [SerializeField] bool PassThroughWalls = true;

    private void Update()
    {
        // normal projectile behavior (sword beam, arrow)
        Vector3 pos = gameObject.transform.position;
        float x_dist = x_move * speed * Time.deltaTime;
        float y_dist = y_move * speed * Time.deltaTime;
        gameObject.transform.position = new Vector3(pos.x + x_dist, pos.y + y_dist, pos.z);

    }

    private void OnBecameInvisible()
    {
        Destroy(gameObject);
    }

    // TODO: explode on walls?
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.GetComponent<HasHealthAndHitbox>() != null)
        { 
            Destroy(gameObject);
        }
        else if (!PassThroughWalls)
        {
            Destroy(gameObject);
        }
    }
}
