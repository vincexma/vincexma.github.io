using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public delegate void InteractionSender2();

public class HasHealthAndHitbox : MonoBehaviour
{
    public TextMeshProUGUI healthDisplayText;

    public AudioSource lowHealth;
    public AudioClip deathSound;
    public AudioClip enemyDeath;

    public double maxHealth = 3.0;
    public double health = 3.0;

    public bool takesKnockback = false;
    public bool invincible = false;
    public ArrowKeyMovement akm;

    public GameObject player;

    public GameObject heart;
    public GameObject rupee;
    public GameObject bomb;
    public GameObject boom;

    public bool can_move = true;

    Animator animator;

    public static InteractionSender on_enemy_defeated;

    

    public void UpdateHealthCount() 
    {
        if (healthDisplayText == null)
            return;
        if (health > 1.0f)
        {
            lowHealth.Stop();
        }
        if (healthDisplayText != null)
        {
            healthDisplayText.text = "Health: " + health.ToString();
        }
    }
    public void FullHeal()
    {
        health = maxHealth;
        UpdateHealthCount();
    }
    public void AddHealth(double amount = 1)
    {
        health += amount;
        if (health > maxHealth)
            health = maxHealth;
        UpdateHealthCount();
    }
    
    public void TakeDamage(double amount)
    {
        if (healthDisplayText != null && GameController.god_mode)
            return;
    
        health -= amount;
        UpdateHealthCount();

        Debug.Log("taking damage");

        if (health <= 1.0 && healthDisplayText != null)
        {
            lowHealth.Play();
        }

        if (health <= 0.0)
        {
            int num = Random.Range(0, 20);
            if (healthDisplayText != null)
            {
                StartCoroutine(deathScene());
            }

            if (akm.state == ArrowKeyMovement.InputAllowed.GEL && on_enemy_defeated != null)
            {
                if (gameObject.transform.position.x > 17.5 && gameObject.transform.position.x < 29.5 &&
                    gameObject.transform.position.y > 34.5 && gameObject.transform.position.y < 41.5)
                {
                    Debug.Log("gel defeated");
                    on_enemy_defeated("gel");
                }
            }
            if (akm.state == ArrowKeyMovement.InputAllowed.KEESE && on_enemy_defeated != null)
            {
                if (gameObject.transform.position.x > 17.5 && gameObject.transform.position.x < 29.5 &&
                    gameObject.transform.position.y > 1.5 && gameObject.transform.position.y < 8.5)
                {
                    Debug.Log("keese defeated");
                    on_enemy_defeated("keese1");
                }

                else if (gameObject.transform.position.x > 17.5 && gameObject.transform.position.x < 29.5 &&
                    gameObject.transform.position.y > 23.5 && gameObject.transform.position.y < 30.5)
                {
                    Debug.Log("locked room keese defeated");
                    on_enemy_defeated("keese2");
                }
            }
            if (akm.state == ArrowKeyMovement.InputAllowed.STALFOS && on_enemy_defeated != null)
            {
                if (gameObject.transform.position.x > 33.5 && gameObject.transform.position.x < 45.5 &&
                    gameObject.transform.position.y > 23.5 && gameObject.transform.position.y < 30.5)
                {
                    Debug.Log("stalfos defeated");
                    on_enemy_defeated("stalfos");
                }
            }

            if (gameObject.transform.childCount == 1 && gameObject.tag != "aqua")
            {
                Debug.Log(gameObject.transform.childCount);
                gameObject.GetComponentInChildren<SpriteRenderer>().enabled = true;
                gameObject.GetComponentInChildren<BoxCollider>().enabled = true;
                gameObject.transform.DetachChildren();
                AudioSource.PlayClipAtPoint(enemyDeath, Camera.main.transform.position);
                Destroy(gameObject);
            }

            else if (num < 4 && akm.state != ArrowKeyMovement.InputAllowed.GORIYA)
            {
                Debug.Log("Spawned random heart");
                GameObject item = Instantiate(heart, gameObject.transform);
                item.transform.localScale = new Vector3(1.1f, 1.1f, 1);
                gameObject.transform.DetachChildren();
                AudioSource.PlayClipAtPoint(enemyDeath, Camera.main.transform.position);
                Destroy(gameObject);
            }
            else if (num < 14 && akm.state == ArrowKeyMovement.InputAllowed.GORIYA && !player.GetComponent<Collector>().boom_dropped)
            {
                Debug.Log("Spawned random boomerang");
                GameObject item = Instantiate(boom, gameObject.transform);
                item.transform.localScale = new Vector3(1.1f, 1.1f, 1);
                gameObject.transform.DetachChildren();
                AudioSource.PlayClipAtPoint(enemyDeath, Camera.main.transform.position);
                Destroy(gameObject);
            }
            else if (num < 14)
            {
                Debug.Log("Spawned random rupee");
                GameObject item = Instantiate(rupee, gameObject.transform);
                item.transform.localScale = new Vector3(0.15f, 0.15f, 1);
                gameObject.transform.DetachChildren();
                AudioSource.PlayClipAtPoint(enemyDeath, Camera.main.transform.position);
                Destroy(gameObject);
            }
            else if (num < 18)
            {
                Debug.Log("Spawned random bomb");
                GameObject item = Instantiate(bomb, gameObject.transform);
                item.transform.localScale = new Vector3(0.15f, 0.15f, 1);
                gameObject.transform.DetachChildren();
                AudioSource.PlayClipAtPoint(enemyDeath, Camera.main.transform.position);
                Destroy(gameObject);
            }
            else
            {
                Debug.Log("Enemy dropped nothing");
                AudioSource.PlayClipAtPoint(enemyDeath, Camera.main.transform.position);
                Destroy(gameObject);
            }
        }
        if (takesKnockback)
            StartCoroutine(akm.LaunchBack());
            StartCoroutine(invincibility());
    }

    IEnumerator invincibility()
    {
        // this method has a bug where if you stay in contact with an enemy during invincibility you'll be safe

        invincible = true;
        yield return new WaitForSeconds(1.5f);
        invincible = false;

        yield return null;
    }

    public IEnumerator stun()
    {
        if (akm.movement_speed != 0)
        {
            /* float temp = akm.movement_speed;
            akm.movement_speed = 0;
            yield return new WaitForSeconds(5.0f);
            akm.movement_speed = temp;
            Debug.Log("stuff is working"); */
            // health -= 15;
            can_move = false;
            yield return new WaitForSeconds(3.0f);
            can_move = true;
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        lowHealth = GetComponent<AudioSource>();
        animator = GetComponent<Animator>();
        akm = GetComponent<ArrowKeyMovement>();
        if (healthDisplayText != null)
        {
            healthDisplayText.text = "Health: " + health.ToString();
        }

        UpdateHealthCount();
        StartCoroutine(invincibility());
    }

    IEnumerator deathScene() {
        akm.DisableAKM();
        AudioSource.PlayClipAtPoint(deathSound, Camera.main.transform.position);
        yield return new WaitForSeconds(3.5f);
        GameController.ResetGame();
        yield return null;
    }


}
