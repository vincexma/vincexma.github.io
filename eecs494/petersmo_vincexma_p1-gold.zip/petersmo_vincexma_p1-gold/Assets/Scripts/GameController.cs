using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public static bool god_mode = false;
    public Inventory playerInv;

    public bool GetMode()
    {
        return god_mode;
    }
    
    void Start()
    {
        Screen.SetResolution(1024, 960, false);
    }

    private void Update()
    {
        if (Input.GetKeyDown("1"))
        {
            ToggleCheatMode();
        }
        else if (Input.GetKeyDown("4"))
        {
            SceneManager.LoadScene("LAB_Level-Design");
        }
    }

    private void ToggleCheatMode()
    {
        god_mode = !god_mode;
        playerInv.UpdateRupeeCount();
        playerInv.UpdateKeyCount();
        playerInv.UpdateBombCount();
    }

    // Call the function below to reset the game (upon death/win)
    public static void ResetGame() 
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
