using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeactivatedByKey : MonoBehaviour
{
    [SerializeField] AudioClip doorOpenSoundClip;

    private void OnCollisionEnter(Collision collision)
    {
        GameObject other = collision.gameObject;
        if(other.CompareTag("Player") && this.gameObject.tag != "boom")
        {
            Inventory playerInv = other.GetComponent<Inventory>();
            if(playerInv.GetKeys() > 0)
            {
                playerInv.UseKeys(1);
                this.gameObject.SetActive(false);
                AudioSource.PlayClipAtPoint(doorOpenSoundClip, Camera.main.transform.position);
            }
        }
    }
}
