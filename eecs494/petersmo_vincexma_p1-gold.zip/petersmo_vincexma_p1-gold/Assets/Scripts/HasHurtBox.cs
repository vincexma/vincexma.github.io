using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public delegate void InteractionSender(string enemy);

public class HasHurtBox : MonoBehaviour
{
    public double attackPower;
    public static InteractionSender on_enemy_defeated;
    public static InteractionSender on_locked_room_enemy_defeated;
    public GameObject mainCam;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("enemy"))
        {
            if (other.gameObject.CompareTag("enemy") && gameObject.CompareTag("enemy"))
            {
                return;
            }
            else
            {
                HasHealthAndHitbox hitbox = other.gameObject.GetComponent<HasHealthAndHitbox>();
                hitbox.TakeDamage(attackPower);
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("enemy") && gameObject.CompareTag("enemy"))
        {
            return;
        }

        if (gameObject.CompareTag("wallmaster"))
        {
            // maybe play some sort of animation here or something
            if (collision.gameObject.CompareTag("Player"))
            {
                HasHealthAndHitbox hitbox = collision.gameObject.GetComponent<HasHealthAndHitbox>();
                if (!hitbox.invincible && !collision.gameObject.GetComponent<GameController>().GetMode())
                {
                    collision.gameObject.transform.position = new Vector3(39.5f, 5, 0);
                    mainCam.transform.position = new Vector3(39.5f, 7, -10);
                }
            }
        }

        HasHealthAndHitbox other = collision.gameObject.GetComponent<HasHealthAndHitbox>();
        ArrowKeyMovement akm = collision.gameObject.GetComponent<ArrowKeyMovement>();
        if (other != null)
        {
            if (gameObject.GetComponent<IsBoomerang>() != null && other.CompareTag("enemy"))
            {
                other.StartCoroutine(other.stun());
            }
            else if (gameObject.tag != collision.gameObject.tag)
            {
                other.TakeDamage(attackPower);
            }
            
        }
    }
}
