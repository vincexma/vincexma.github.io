using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class ArrowKeyMovement : MonoBehaviour
{
    BladeTrapActivate bta;
    Rigidbody rb;
    public float movement_speed = 4;
    private Vector2 prev_input = new Vector2(0, 0);
    WeaponAttack wp;

    public enum InputAllowed
    {
        ENABLED,
        DISABLED,
        BOWROOM,
        STALFOS,
        KEESE,
        GORIYA,
        GEL,
        BLADE,
        WALLMASTER,
        AQUA
    }

    public Vector2 faceDirection = new Vector2(0, -1);

    public enum EnemyState
    {
        MOVING,
        READY
    }

    public InputAllowed state = InputAllowed.ENABLED;
    public EnemyState enemy = EnemyState.READY;
    public InputAllowed entity_type = InputAllowed.DISABLED;
    int motionCounter = 0;
    int attackCounter = 0;
    int num = -1;
    int num1 = -1;

    float temp = 0;

    // Start is called before the first frame update
    void Start()
    {
        bta = GetComponent<BladeTrapActivate>();
        wp = GetComponentInChildren<WeaponAttack>();
        rb = GetComponent<Rigidbody>();
        entity_type = state;
    }

    // Update is called once per frame
    void Update()
    {
        if (GetComponent<HasHealthAndHitbox>() != null)
        {
            if (state != InputAllowed.ENABLED && movement_speed != 0 && !GetComponent<HasHealthAndHitbox>().can_move)
            {
                temp = movement_speed;
                movement_speed = 0;
            }
            if (movement_speed == 0 && GetComponent<HasHealthAndHitbox>().can_move)
            {
                movement_speed = temp;
            }
        }
        if (state != InputAllowed.DISABLED)
        {
            // get input gets vector of input movement
            Vector2 current_input = GetInput();
            if (current_input != prev_input && current_input != Vector2.zero)
            {
                double newX;
                double newY;
                // send link directly to the nearest .25 of a block
                // idea: i think the smoothest way to do this is to keep his velocity in the direction i want to send him
                //      to till he gets there instead of just sending him there. this might take a lot of work so i will do this later if at all
                if (current_input.x == 0)
                {
                    // run this if user input was previously horizontal and is now vertical
                    // rounds new x position to the nearest .5
                    if (rb.transform.position.x % .25 >= .375)
                    {
                        newX = rb.transform.position.x + (.5 - (rb.transform.position.x % .5));
                    }
                    else if (rb.transform.position.x % .25 > .125 && rb.transform.position.x % .25 < .375)
                    {
                        newX = rb.transform.position.x + (.25 - (rb.transform.position.x % .25));
                    }
                    
                    else
                    {
                        newX = rb.transform.position.x - (rb.transform.position.x % .5);
                    }
                    rb.MovePosition(new Vector2((float)newX, rb.transform.position.y));
                }

                else if (current_input.y == 0)
                {
                    // run this if user input was previously vertical and is now horizontal
                    // rounds new x position to the nearest .5
                    if (rb.transform.position.y % .5 >= .25)
                    {
                        newY = rb.transform.position.y + (.5 - (rb.transform.position.y % .5));
                    }
                    else
                    {
                        newY = rb.transform.position.y - (rb.transform.position.y % .5);
                    }
                    rb.MovePosition(new Vector2(rb.transform.position.x, (float)newY));
                }
                else
                {
                    if (current_input.y != 0.0f && Mathf.Abs(rb.velocity.x) > 0.0f)
                    {
                        rb.velocity = new Vector2(0, current_input.y * movement_speed);
                    }
                }
            }
            // set current input to previous input for next comparison
            prev_input = current_input;

            // turn input vector into velocity of rigidbody
            rb.velocity = current_input * movement_speed;
        }
    }

    public void DisableAKM() 
    {
        state = InputAllowed.DISABLED;
    }
    public void EnableAKM()
    {
        state = entity_type;
    }

    public IEnumerator Stun(float StunTime)
    {
        rb.velocity = Vector2.zero;
        DisableAKM();
        yield return new WaitForSeconds(StunTime);
        EnableAKM();
        Debug.Log("Stunned");
        yield return null;
    }

    public IEnumerator LaunchBack()
    {
        state = InputAllowed.DISABLED;
        rb.velocity = new Vector2(faceDirection.x * -10, faceDirection.y * -10);
        yield return new WaitForSeconds(0.3f);
        rb.velocity = Vector2.zero;
        state = entity_type;
        Debug.Log("Launched");
        yield return null;
    }

    public Vector2 GetInput()
    {
        float horizontal_input = 0.0f;
        float vertical_input = 0.0f;
        // get axis raw gets value of right-left and up-down arrow keys (also works for wasd)
        // return statement returns the vector of movement given by input
        if (state == InputAllowed.ENABLED || state == InputAllowed.BOWROOM)
        {
            horizontal_input = Input.GetAxisRaw("Horizontal");
            vertical_input = Input.GetAxisRaw("Vertical");

            if (Mathf.Abs(rb.velocity.y) > 0.0f)
            {
                // if moving horizontally, dont allow vertical movement
                // eliminates diagonal moves
                if (Input.GetKeyDown("a") || Input.GetKeyDown("d") || Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.LeftArrow))
                {
                    
                    vertical_input = 0.0f;
                }
                else
                {
                    horizontal_input = 0.0f;
                }
            }
            else if (Mathf.Abs(rb.velocity.x) > 0.0f)
            {
                // if moving horizontally, dont allow vertical movement
                // eliminates diagonal moves
                if (Input.GetKeyDown("w") || Input.GetKeyDown("s") || Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.DownArrow))
                {
                    horizontal_input = 0.0f;
                    
                }
                else
                {
                    vertical_input = 0.0f;
                }
            }
            if (state == InputAllowed.BOWROOM)
            {
                if (!(rb.transform.position.x >= 18.45 && rb.transform.position.x <= 19))
                {
                    if (!(rb.transform.position.x >= 26.5 && rb.transform.position.x <= 27 && rb.transform.position.y <= 49.5)) {
                        Debug.Log("not allowing vertical movement");
                        vertical_input = 0.0f;
                    }
                }
            }
        }
        else
        {
            if (state == InputAllowed.GEL)
            {
                if (enemy == EnemyState.READY)
                {
                    num = Random.Range(0, 4);

                    if (num == 0)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = 1.0f;
                        enemy = EnemyState.MOVING;
                    }
                    else if (num == 1)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = -1.0f;
                        enemy = EnemyState.MOVING;
                    }
                    else if (num == 2)
                    {
                        horizontal_input = 1.0f;
                        vertical_input = 0.0f;
                        enemy = EnemyState.MOVING;
                    }
                    else if (num == 3)
                    {
                        horizontal_input = -1.0f;
                        vertical_input = 0.0f;
                        enemy = EnemyState.MOVING;
                    }
                }
                else
                {
                    if (num == 0)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = 1.0f;
                    }
                    else if (num == 1)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = -1.0f;
                    }
                    else if (num == 2)
                    {
                        horizontal_input = 1.0f;
                        vertical_input = 0.0f;
                    }
                    else if (num == 3)
                    {
                        horizontal_input = -1.0f;
                        vertical_input = 0.0f;
                    }

                    ++motionCounter;
                    if (motionCounter == 30)
                    {
                        num = 4;
                        horizontal_input = 0.0f;
                        vertical_input = 0.0f;
                    }
                    if (motionCounter == 200)
                    {
                        enemy = EnemyState.READY;
                        motionCounter = 0;
                    }
                }
            }
            if (state == InputAllowed.BLADE)
            {
                if (enemy == EnemyState.MOVING)
                {
                    if (bta.direction.x == 1)
                    {
                        horizontal_input = 1.0f;
                        vertical_input = 0.0f;
                    }
                    if (bta.direction.x == -1)
                    {
                        horizontal_input = -1.0f;
                        vertical_input = 0.0f;
                    }
                    if (bta.direction.y == 1)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = 1.0f;
                    }
                    if (bta.direction.y == -1)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = -1.0f;
                    }
                    ++motionCounter;
                    if (bta.direction.y != 0)
                    {
                        if (motionCounter == 200)
                        {
                            bta.direction.x *= -1;
                            bta.direction.y *= -1;
                        }
                        if (motionCounter == 450)
                        {
                            motionCounter = 0;
                            enemy = EnemyState.READY;
                        }
                    }
                    else
                    {
                        if (motionCounter == 300)
                        {
                            bta.direction.x *= -1;
                            bta.direction.y *= -1;
                        }
                        if (motionCounter == 600)
                        {
                            motionCounter = 0;
                            enemy = EnemyState.READY;
                        }
                    }
                }
            }
            if (state == InputAllowed.STALFOS)
            {
                // for the finished state of the game we should try to make it so enemies cant go too close to the doors
                if (enemy == EnemyState.READY)
                {
                    num = Random.Range(0, 400);

                    if (num == 0)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = 1.0f;
                        enemy = EnemyState.MOVING;
                    }
                    else if (num == 1)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = -1.0f;
                        enemy = EnemyState.MOVING;
                    }
                    else if (num == 2)
                    {
                        horizontal_input = 1.0f;
                        vertical_input = 0.0f;
                        enemy = EnemyState.MOVING;
                    }
                    else if (num == 3)
                    {
                        horizontal_input = -1.0f;
                        vertical_input = 0.0f;
                        enemy = EnemyState.MOVING;
                    }
                    else
                    {
                        horizontal_input = 0.0f;
                        vertical_input = 0.0f;
                    }
                }
                else
                {
                    if (num == 0)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = 1.0f;
                    }
                    else if (num == 1)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = -1.0f;
                    }
                    else if (num == 2)
                    {
                        horizontal_input = 1.0f;
                        vertical_input = 0.0f;
                    }
                    else if (num == 3)
                    {
                        horizontal_input = -1.0f;
                        vertical_input = 0.0f;
                    }
                    else
                    {
                        horizontal_input = 0.0f;
                        vertical_input = 0.0f;
                    }
                    ++motionCounter;
                    if (motionCounter == 150)
                    {
                        enemy = EnemyState.READY;
                        motionCounter = 0;
                    }
                }
            }
            else if (state == InputAllowed.GORIYA)
            {
                // for the finished state of the game we should try to make it so enemies cant go too close to the doors
                if (enemy == EnemyState.READY)
                {
                    num = Random.Range(0, 400);

                    if (num == 0)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = 1.0f;
                        enemy = EnemyState.MOVING;
                    }
                    else if (num == 1)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = -1.0f;
                        enemy = EnemyState.MOVING;
                    }
                    else if (num == 2)
                    {
                        horizontal_input = 1.0f;
                        vertical_input = 0.0f;
                        enemy = EnemyState.MOVING;
                    }
                    else if (num == 3)
                    {
                        horizontal_input = -1.0f;
                        vertical_input = 0.0f;
                        enemy = EnemyState.MOVING;
                    }
                    else
                    {
                        horizontal_input = 0.0f;
                        vertical_input = 0.0f;
                    }
                }
                else
                {
                    if (num == 0)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = 1.0f;
                    }
                    else if (num == 1)
                    {
                        horizontal_input = 0.0f;
                        vertical_input = -1.0f;
                    }
                    else if (num == 2)
                    {
                        horizontal_input = 1.0f;
                        vertical_input = 0.0f;
                    }
                    else if (num == 3)
                    {
                        horizontal_input = -1.0f;
                        vertical_input = 0.0f;
                    }
                    else
                    {
                        horizontal_input = 0.0f;
                        vertical_input = 0.0f;
                    }
                    ++motionCounter;
                    ++attackCounter;
                    if (attackCounter == 2000)
                    {
                        attackCounter = 0;

                        // wp.doAttack(state);

                    }
                    if (motionCounter == 700)
                    {
                        enemy = EnemyState.READY;
                        motionCounter = 0;
                    }
                }
            }
            else if (state == InputAllowed.KEESE)
            {

                if (enemy == EnemyState.READY)
                {

                    while (true)
                    {
                        num = Random.Range(-1, 1);
                        num1 = Random.Range(-1, 1);
                        if (num != 0 || num1 != 0)
                        {
                            break;
                        }
                    }
                    horizontal_input = num;
                    vertical_input = num1;
                    enemy = EnemyState.MOVING;
                }
                else
                {
                    horizontal_input = num;
                    vertical_input = num1;
                    ++motionCounter;


                    if (motionCounter == 1000)
                    {
                        int num2 = Random.Range(0, 3);
                        if (num2 == 2)
                        {
                            enemy = EnemyState.READY;

                        }
                        motionCounter = 0;
                        num = -1 * num;
                        num1 = -1 * num1;

                    }
                }
            }
            else if (state == InputAllowed.AQUA)
            {
                horizontal_input = 1.0f;
                vertical_input = 0.0f;
                ++motionCounter;


                if (motionCounter >= 1250)
                {
                    horizontal_input = -1 * horizontal_input;
                }
                if (motionCounter == 2500)
                {
                    motionCounter = 0;
                }
            }
            else if (state == InputAllowed.WALLMASTER)
            {

                if (enemy == EnemyState.READY)
                {
                    if (rb.transform.position.x < 68)
                    {
                        enemy = EnemyState.MOVING;
                        // num = Random.Range(0, 3);

                        horizontal_input = 1.0f;
                        vertical_input = 0.0f;
                        num = 1;
                        num1 = 0;

                    }
                    else if (rb.transform.position.x > 75)
                    {
                        enemy = EnemyState.MOVING;
                        horizontal_input = -1.0f;
                        vertical_input = 0.0f;
                        num = -1;
                        num1 = 0;

                    }
                    else if (rb.transform.position.y < 35)
                    {
                        enemy = EnemyState.MOVING;

                        horizontal_input = 0.0f;
                        vertical_input = 1.0f;
                        num = 0;
                        num1 = 1;

                    }
                    else if (rb.transform.position.y > 39)
                    {
                        enemy = EnemyState.MOVING;

                        horizontal_input = 0.0f;
                        vertical_input = -1.0f;
                        num = 0;
                        num1 = -1;

                    }
                }
                else
                {

                    horizontal_input = num;
                    vertical_input = num1;
                    if (rb.velocity == Vector3.zero)
                    {
                        horizontal_input = -1 * num1;
                        vertical_input = -1 * num;
                    }
                }
            }
        }
        if (horizontal_input != 0 || vertical_input != 0)
        {
            faceDirection = new Vector2(horizontal_input, vertical_input);

        }
        
        
        return new Vector2(horizontal_input, vertical_input);
    }
}
