using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Despawns : MonoBehaviour
{
    [SerializeField] float lifespan = 1.5f;

    void Update()
    {
        if (lifespan > 0.0f)
        {
            lifespan -= Time.deltaTime;
        }
        else
        {
            Destroy(gameObject);
        }
    }
}
