using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnEnemy : MonoBehaviour
{
    public GameObject cam;
    public GameObject enemy;
    ArrowKeyMovement akm;
    SpriteRenderer sr;
    float move_speed;

    public Animation spawn;

    private void Start()
    {
        akm = GetComponent<ArrowKeyMovement>();
        sr = GetComponent<SpriteRenderer>();
        move_speed = akm.movement_speed;
    }
    // Start is called before the first frame update

    private void Update()
    {
        if ((enemy.transform.position.x > (cam.transform.position.x - 7.5) && enemy.transform.position.x < (cam.transform.position.x + 7.5)) &&
            (enemy.transform.position.y > (cam.transform.position.y - 6) && enemy.transform.position.y < (cam.transform.position.y + 6)))
        {

            akm.movement_speed = move_speed;
            sr.enabled = true;
        }
        else
        {
            akm.movement_speed = 0;
            sr.enabled = false;
        }
    }
}
