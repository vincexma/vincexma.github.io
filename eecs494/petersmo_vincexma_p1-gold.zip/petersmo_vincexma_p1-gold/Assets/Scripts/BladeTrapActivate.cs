using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BladeTrapActivate : MonoBehaviour
{
    public Vector2 direction;
    Rigidbody rb;
    Ray trapY;
    Ray trapX;
    Ray ntrapX;
    Ray ntrapY;
    RaycastHit hit;
    ArrowKeyMovement akm;
    // Start is called before the first frame update
    void Start()
    {
        akm = GetComponent<ArrowKeyMovement>();
        rb = GetComponent<Rigidbody>();
        trapY = new Ray(new Vector3(rb.position.x, rb.position.y, 0), new Vector3(0, 10, 0));
        trapX = new Ray(new Vector3(rb.position.x, rb.position.y, 0), new Vector3(17, 0, 0));
        ntrapY = new Ray(new Vector3(rb.position.x, rb.position.y, 0), new Vector3(0, -10, 0));
        ntrapX = new Ray(new Vector3(rb.position.x, rb.position.y, 0), new Vector3(-17, 0, 0));
        
    }

    // Update is called once per frame
    void Update()
    {
        Debug.DrawRay(new Vector3(rb.position.x, rb.position.y, 0), new Vector3(0, 10, 0));
        Debug.DrawRay(new Vector3(rb.position.x, rb.position.y, 0), new Vector3(17, 0, 0));
        Debug.DrawRay(new Vector3(rb.position.x, rb.position.y, 0), new Vector3(0, -10, 0));
        Debug.DrawRay(new Vector3(rb.position.x, rb.position.y, 0), new Vector3(-17, 0, 0));
        if (Physics.Raycast(trapY, out hit) && akm.enemy == ArrowKeyMovement.EnemyState.READY)
        {
            GameObject hitObject = hit.transform.gameObject;
            if (hitObject.CompareTag("Player"))
            {
                direction = new Vector2(0, 1);
                akm.enemy = ArrowKeyMovement.EnemyState.MOVING;
            }
        }
        if (Physics.Raycast(trapX, out hit) && akm.enemy == ArrowKeyMovement.EnemyState.READY)
        {
            GameObject hitObject = hit.transform.gameObject;
            if (hitObject.CompareTag("Player"))
            {
                direction = new Vector2(1, 0);
                akm.enemy = ArrowKeyMovement.EnemyState.MOVING;
            }
        }
        if (Physics.Raycast(ntrapX, out hit) && akm.enemy == ArrowKeyMovement.EnemyState.READY)
        {
            GameObject hitObject = hit.transform.gameObject;
            if (hitObject.CompareTag("Player"))
            {
                direction = new Vector2(-1, 0);
                akm.enemy = ArrowKeyMovement.EnemyState.MOVING;
            }
        }
        if (Physics.Raycast(ntrapY, out hit) && akm.enemy == ArrowKeyMovement.EnemyState.READY)
        {
            GameObject hitObject = hit.transform.gameObject;
            if (hitObject.CompareTag("Player"))
            {
                direction = new Vector2(0, -1);
                akm.enemy = ArrowKeyMovement.EnemyState.MOVING;
            }
        }
    }
}
