using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActivatedByPlayerDirectionAndKeyDown : MonoBehaviour
{
    [SerializeField] GameObject entity;

    [SerializeField] GameObject NorthPrefab;
    [SerializeField] GameObject SouthPrefab;
    [SerializeField] GameObject EastPrefab;
    [SerializeField] GameObject WestPrefab;

    [SerializeField] Sprite animationFlagNorth;
    [SerializeField] Sprite animationFlagSouth;
    [SerializeField] Sprite animationFlagEast;
    [SerializeField] Sprite animationFlagWest;

    [SerializeField] public string activatingKey;

    [SerializeField] float despawnTime = 1.5f;

    [SerializeField] bool stopsUser = false;
    [SerializeField] bool requiresRupees = false;
    [SerializeField] bool requiresBombs = false;
    [SerializeField] bool requiresMaxHealth = false;
    [SerializeField] bool globalExclusiveActivation = false;
    [SerializeField] bool localExclusiveActivation = false;
    [SerializeField] bool spawnUnderPlayer = false;

    public Animator animator;

    public bool enabled = false;

    public AudioClip sword;
    public AudioClip swordLaunch;

    static bool active = false;
    bool localActive = false;

    public bool unlocked;
    public enum AI
    {
        AQUAMENTUS,
        NONE,
        GORIYA
    }
    private int attackTimer = 0;
    public AI auto = AI.NONE;

    private void Start()
    {
        animator = GetComponentInParent<Animator>();
    }

    private void Update()
    {
        if (active || !enabled)
        {
            return;
        }

        if(localExclusiveActivation && localActive)
        {
            return;
        }

        // the sword fires a beam only at max hp
        HasHealthAndHitbox life = entity.GetComponent<HasHealthAndHitbox>();
        if (requiresMaxHealth && (life.health < life.maxHealth))
        {
            return;
        }
        if (auto == AI.AQUAMENTUS || auto == AI.GORIYA)
        {
            ++attackTimer;
        }

        if ((Input.GetKeyDown(activatingKey) && (unlocked || GameController.god_mode) || attackTimer == 1000))
        {
            // using the bow costs rupees
            Inventory inv = entity.GetComponent<Inventory>();
            if (requiresRupees)
            {
                if (inv.GetRupees() < 1)
                {
                    return;
                }
                inv.UseRupees(1);
            }
            if (requiresBombs)
            {
                if (inv.GetBombs() < 1)
                {
                    return;
                }
                inv.UseBombs(1);
            }

            if (attackTimer == 1000)
            {
                attackTimer = 0;
            }

            Vector2 faceDir = entity.GetComponent<ArrowKeyMovement>().faceDirection;
            Debug.Log("keydown " + activatingKey + " detected with " + faceDir.ToString());

            Vector3 spawnPos = new Vector3(entity.transform.position.x + faceDir.x,
                                           entity.transform.position.y + faceDir.y,
                                           entity.transform.position.z);
            if (spawnUnderPlayer)
            {
                StartCoroutine(UsePrefabObject(NorthPrefab, entity.transform.position, animationFlagNorth));
            }

            else if (-0.1 < faceDir.x  && faceDir.x < 0.1)
            {
                // north
                if(faceDir.y > 0.1)
                {
                    StartCoroutine(UsePrefabObject(NorthPrefab, spawnPos, animationFlagNorth));
                }
                // south
                else
                {
                    StartCoroutine(UsePrefabObject(SouthPrefab, spawnPos, animationFlagSouth));
                }
            }
            else if (auto == AI.AQUAMENTUS)
            {
                StartCoroutine(UsePrefabObjectDragon(WestPrefab, spawnPos));
            }
            else
            {
                // east
                if (faceDir.x > 0.1)
                {
                    StartCoroutine(UsePrefabObject(EastPrefab, spawnPos, animationFlagEast));
                }
                // west
                else
                {
                    StartCoroutine(UsePrefabObject(WestPrefab, spawnPos, animationFlagWest));
                }
            }
        }
    }

    IEnumerator UsePrefabObject (GameObject prefab, Vector3 position, Sprite animation_trigger)
    {
        if (gameObject.tag == "sword")
        {
            if (!requiresMaxHealth)
            {
                GetComponentInParent<Animator>().enabled = false;
                GetComponentInParent<SpriteRenderer>().sprite = animation_trigger;
            }
            AudioSource.PlayClipAtPoint(sword, Camera.main.transform.position);
            if (this.gameObject.GetComponentInParent<HasHealthAndHitbox>().health == 3.0f)
            {
                AudioSource.PlayClipAtPoint(swordLaunch, Camera.main.transform.position);
            }
        }

        GameObject clone = (GameObject)Instantiate(prefab, position, Quaternion.identity);

        if(clone.GetComponent<IsBoomerang>() != null)
        {
            clone.GetComponent<IsBoomerang>().ProjectileSource = entity;
        }

        ArrowKeyMovement akm = entity.GetComponent<ArrowKeyMovement>();
        if (stopsUser)
        {
            akm.state = ArrowKeyMovement.InputAllowed.DISABLED;
            entity.GetComponent<Rigidbody>().velocity = Vector2.zero;
        }
        if (globalExclusiveActivation)
        {
            active = globalExclusiveActivation;
        }
        if (localExclusiveActivation)
        {
            localActive = true;
        }

        // animator.SetTrigger(animation_trigger);
        Debug.Log("launching weapon");
        yield return new WaitForSeconds(despawnTime);
        Debug.Log("weapon launched");
        // animator.ResetTrigger(animation_trigger);
        Destroy(clone);
        active = false;
        localActive = false;
        akm.state = akm.entity_type;

        yield return null;
    }

    IEnumerator UsePrefabObjectDragon(GameObject prefab, Vector3 position)
    {
        position.x -= 1.0f;
        GameObject clone1 = (GameObject)Instantiate(prefab, position, Quaternion.identity);
        position.y += 1.5f;
        GameObject clone2 = (GameObject)Instantiate(prefab, position, Quaternion.identity);
        position.y -= 3.0f;
        GameObject clone3 = (GameObject)Instantiate(prefab, position, Quaternion.identity);
        ArrowKeyMovement akm = entity.GetComponent<ArrowKeyMovement>();
        if (stopsUser)
        {
            akm.state = ArrowKeyMovement.InputAllowed.DISABLED;
            entity.GetComponent<Rigidbody>().velocity = Vector2.zero;
        }
        if (globalExclusiveActivation)
        {
            active = true;
        }
        // animator.SetTrigger(animation_trigger);
        Debug.Log("launching weapon");
        yield return new WaitForSeconds(3.0f);
        Debug.Log("weapon launched");
        // animator.ResetTrigger(animation_trigger);
        Destroy(clone1);
        Destroy(clone2);
        Destroy(clone3);
        active = false;
        akm.state = akm.entity_type;

        yield return null;
    }
}
