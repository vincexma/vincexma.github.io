using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotator : MonoBehaviour
{
    [SerializeField] float rotateAmount = 90f; 
    [SerializeField] float timeToRotate = 0.15f;
    float time_elapsed = 0.0f;
    void Update()
    {
        time_elapsed += Time.deltaTime;
        if (time_elapsed >= timeToRotate)
        {
            time_elapsed = 0;
            transform.Rotate(new Vector3(0, 0, rotateAmount));
        }
    }
}
