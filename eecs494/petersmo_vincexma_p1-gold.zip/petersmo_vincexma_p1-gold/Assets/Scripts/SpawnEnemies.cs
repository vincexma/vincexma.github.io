using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnEnemies : MonoBehaviour
{
    public GameObject cam;
    public GameObject enemy;
    ArrowKeyMovement akm;
    SpriteRenderer sr;

    float move_speed;
    // Start is called before the first frame update
    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        akm = GetComponent<ArrowKeyMovement>();
        move_speed = akm.movement_speed;
    }

    // Update is called once per frame
    void Update()
    {
        if ((enemy.transform.position.x < cam.transform.position.x + 7.5 && enemy.transform.position.x > cam.transform.position.x - 7.5) &&
            (enemy.transform.position.y < cam.transform.position.y + 6.5 && enemy.transform.position.y > cam.transform.position.y - 6.5)) {
            akm.movement_speed = move_speed;
            sr.enabled = true;
        }
        else
        {
            akm.movement_speed = 0;
            sr.enabled = false;
        }
    }
}
