using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IsBoomerang : MonoBehaviour
{
    public GameObject ProjectileSource;
    [SerializeField] float ThrowTime = 1.5f;
    [SerializeField] float ThrowSpeed = 2.5f;
    [SerializeField] float ReturnSpeed = 2.5f;
    [SerializeField] float StunTime = 0.3f;

    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("Boomerang Sent");
        gameObject.tag = ProjectileSource.tag;
        StartCoroutine(FlyOutAndReturn());
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject == ProjectileSource)
        {
            //deactivate the boomerang here
            Debug.Log("Boomerang Destroyed");
            Destroy(gameObject);
        }

        if(collision.gameObject.GetComponent<ArrowKeyMovement>() != null
            && !collision.gameObject.CompareTag(ProjectileSource.tag))
        {
            collision.gameObject.GetComponent<ArrowKeyMovement>().Stun(StunTime);
        }
    }

    IEnumerator FlyOutAndReturn()
    {
        Vector3 source = gameObject.transform.position;
        Vector3 offset = ProjectileSource.GetComponent<ArrowKeyMovement>().faceDirection * 3;
        Debug.Log(offset.ToString());

        // Fly to faceDir + 3
        gameObject.GetComponent<Rigidbody>().velocity = offset * ThrowSpeed;
        yield return new WaitForSeconds(ThrowTime);

        Debug.Log("Boomerang Returning");
        
        // Fly back to source (player)
        while (true)
        {
            source = ProjectileSource.transform.position;
            gameObject.GetComponent<Rigidbody>().velocity = (source - gameObject.transform.position).normalized * ReturnSpeed;
            yield return null;
        }
    }
}
