using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomTransition : MonoBehaviour
{
    public Rigidbody rb;
    public GameObject cam;
    private ArrowKeyMovement akm;

    void OnTriggerEnter(Collider other)
    {
        GameObject object_collided_with = other.gameObject;
        if ((object_collided_with.CompareTag("updoor") || object_collided_with.CompareTag("leftdoor") || 
            object_collided_with.CompareTag("downdoor") || object_collided_with.CompareTag("rightdoor"))
            && akm.state == ArrowKeyMovement.InputAllowed.ENABLED)
        {
            StartCoroutine(TransitionRooms(object_collided_with));
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        akm = GetComponent<ArrowKeyMovement>();
    }

    IEnumerator TransitionRooms(GameObject obj)
    {
        akm.state = ArrowKeyMovement.InputAllowed.DISABLED;
        Vector2 next_vel;

        Vector3 initial_position = new Vector3(cam.transform.position.x, cam.transform.position.y, -10);
        Vector3 final_position;
        if (obj.CompareTag("updoor"))
        {
            final_position = new Vector3(initial_position.x, initial_position.y + 11, -10);
            next_vel = new Vector2(0, 4);
        }
        else if (obj.CompareTag("downdoor"))
        {
            final_position = new Vector3(initial_position.x, initial_position.y - 11, -10);
            next_vel = new Vector2(0, -4);
        }
        else if (obj.CompareTag("leftdoor"))
        {
            final_position = new Vector3(initial_position.x - 16, initial_position.y, -10);
            next_vel = new Vector2(-4, 0);
        }
        else if (obj.CompareTag("rightdoor"))
        {
            final_position = new Vector3(initial_position.x + 16, initial_position.y, -10);
            next_vel = new Vector2(4, 0);
        }
        else
        {
            Debug.Log("edge case in room transition found");
            final_position = new Vector3(initial_position.x, initial_position.y, -10);
            next_vel = new Vector2(50, 50);
        }

        yield return StartCoroutine(MoveObject(cam.transform, initial_position, final_position, 2.0f, rb, next_vel));

        akm.state = ArrowKeyMovement.InputAllowed.ENABLED;
        yield return null;
    }

    IEnumerator MoveObject(Transform target, Vector3 init, Vector3 dest, float duration, Rigidbody rb, Vector2 next_vel)
    {
        
        float initial_time = Time.time;
        // The "progress" variable will go from 0.0f -> 1.0f over the course of "duration_sec" seconds.
        float progress = (Time.time - initial_time) / duration;

        while (progress < 1.0f)
        {
            if (progress > 0.12f)
            {
                rb.velocity = Vector2.zero;
            }
            // Recalculate the progress variable every frame. Use it to determine
            // new position on line from "initial_pos" to "dest_pos"
            progress = (Time.time - initial_time) / duration;
            Vector3 new_position = Vector3.Lerp(init, dest, progress);
            target.position = new_position;

            // yield until the end of the frame, allowing other code / coroutines to run
            // and allowing time to pass.
            yield return null;
        }

        target.position = dest;

        rb.velocity = next_vel;

        yield return new WaitForSeconds(0.6f);
        yield return null;
    }
}
