using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputToAnimator : MonoBehaviour
{
    Animator animator;

    ArrowKeyMovement akm;

    // Start is called before the first frame update
    void Start()
    {
        akm = GetComponent<ArrowKeyMovement>();
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        animator.SetFloat("horizontal_input", akm.GetInput().x);
        animator.SetFloat("vertical_input", akm.GetInput().y);
        


        // disable sprite animation when the player isn't inputting anything
        if (Input.GetAxisRaw("Horizontal") == 0.0f && Input.GetAxisRaw("Vertical") == 0.0f)
        {
            animator.enabled = false;
        }
        else if (akm.state == ArrowKeyMovement.InputAllowed.DISABLED)
        {
            animator.enabled = false;
        }
        else
        {
            animator.enabled = true;
        }
    }
}
