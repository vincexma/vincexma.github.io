using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TeleportToNearestWhole : MonoBehaviour
{
    void Start()
    {
        Vector3 pos = gameObject.transform.position;
        pos.x = Mathf.Round(pos.x);
        pos.y = Mathf.Round(pos.y);
        gameObject.transform.position = pos;
    }
}
