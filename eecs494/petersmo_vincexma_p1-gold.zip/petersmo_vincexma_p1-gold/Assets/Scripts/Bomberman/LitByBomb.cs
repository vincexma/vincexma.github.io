using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LitByBomb : MonoBehaviour
{
    [SerializeField] GameObject permFlame;
    [SerializeField] GameObject tempFlame;
    [SerializeField] public bool selfExtinguishing = false;
    [SerializeField] float extinguishTime = 2.0f;

    float timeLeft;
    bool lit = false;

    // Start is called before the first frame update
    void Start()
    {
        permFlame.SetActive(false);
        tempFlame.SetActive(false);
    }

    private void Update()
    {
        if (selfExtinguishing)
        {
            timeLeft -= Time.deltaTime;
            if(timeLeft < 0)
            {
                SetFlame(false);
            }
        }        
    }

    public void SetFlame(bool light)
    {
        lit = light;
        if (selfExtinguishing)
        {
            tempFlame.SetActive(light);
            timeLeft = extinguishTime;
        }
        else
        {
            permFlame.SetActive(light);
        }
    }

    public bool getCandleStatus()
    {
        return lit;
    }
}
