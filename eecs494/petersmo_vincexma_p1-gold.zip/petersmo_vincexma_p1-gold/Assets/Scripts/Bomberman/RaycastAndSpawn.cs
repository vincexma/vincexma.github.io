using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RaycastAndSpawn : MonoBehaviour
{

    public int explosionSize = 1;
    [SerializeField] float explosionTime = 3.0f;
    [SerializeField] GameObject spawnedObject;

    static Vector3[] dirs = new Vector3[4] {Vector2.up, Vector2.down, Vector2.left, Vector2.right};
    public bool inChain = false;

    private void Update()
    {
        explosionTime -= Time.deltaTime;
        if(explosionTime < 0)
        {
            inChain = true;
            Destroy(gameObject);
        }
    }

    // returns the amount of open space in one direction
    private float OpenDist(Vector2 direction) 
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position, transform.TransformDirection(direction), out hit, explosionSize))
        {
            //if raycast hits other bomb that is not already in the chain, destroy that bomb
            if (hit.transform.gameObject.GetComponent<RaycastAndSpawn>() != null
                && !hit.transform.gameObject.GetComponent<RaycastAndSpawn>().inChain)
            {
                Destroy(hit.transform.gameObject);
            }
            else if (hit.transform.gameObject.GetComponent<DestroyedByExplosion>() != null)
            {
                Destroy(hit.transform.gameObject);
                return hit.distance + 1;
            }
            else if (hit.transform.gameObject.GetComponent<LitByBomb>() != null)
            {
                hit.transform.gameObject.GetComponent<LitByBomb>().SetFlame(true);
                return hit.distance + 1;
            }

            return hit.distance;
        }
        return explosionSize;
    }

    private void OnDestroy()
    {
        Instantiate(spawnedObject, gameObject.transform.position, Quaternion.identity);

        // raycast in each direction by explosionSize and spawn flames
        for (int i = 0; i < 4; ++i)
        {
            float dist = OpenDist(dirs[i]);
            for(int fire = 1; fire <= dist; ++fire)
            {
                Vector3 pos = gameObject.transform.position + dirs[i] * fire;
                Instantiate(spawnedObject, pos, Quaternion.identity);
            }
        }
    }
}
