using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpensWhenAllChildrenAreLit : MonoBehaviour
{
    [SerializeField] List<GameObject> children;
    void Update()
    {
        foreach (GameObject child in children)
        {
            if (!child.GetComponent<LitByBomb>().getCandleStatus())
            {
                return;
            }
        }

        Destroy(gameObject);
    }
    private void OnDestroy()
    {
        foreach (GameObject child in children)
        {
            child.GetComponent<LitByBomb>().selfExtinguishing = false;
        }
    }
}
