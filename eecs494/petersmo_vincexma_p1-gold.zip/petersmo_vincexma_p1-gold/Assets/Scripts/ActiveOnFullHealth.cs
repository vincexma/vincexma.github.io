using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActiveOnFullHealth : MonoBehaviour
{
    [SerializeField] GameObject parentEntity;

    void Start()
    {
        HasHealthAndHitbox entityHealth = parentEntity.GetComponent<HasHealthAndHitbox>();
        if (entityHealth.health + 0.1f < entityHealth.maxHealth)
            Destroy(gameObject);
    }
}
