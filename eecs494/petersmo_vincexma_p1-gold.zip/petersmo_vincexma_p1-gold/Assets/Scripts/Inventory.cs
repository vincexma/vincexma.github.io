using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Inventory : MonoBehaviour
{
    public TextMeshProUGUI rupeeDisplayText;
    public TextMeshProUGUI keyDisplayText;
    public TextMeshProUGUI bombDisplayText;

    int rupee_count = 0;
    int key_count = 0;
    int bomb_count = 0;

    private void Start()
    {
        Collector.collectedItem += AddRemoteItemPickup;
        UpdateRupeeCount();
        UpdateKeyCount();
        UpdateBombCount();
    }

    public void AddRemoteItemPickup(string item)
    {
        if (item == "rupee")
        {
            AddRupees(1);
        }
        if (item == "bomb")
        {
            AddBombs(1);
        }
        if (item == "key")
        {
            AddKeys(1);
        }
        if (item == "health")
        {
            gameObject.GetComponent<HasHealthAndHitbox>().AddHealth(1);
        }
    }

    public void UpdateRupeeCount()
    {
        rupeeDisplayText.text = "x" + GetRupees().ToString();
    }
    public void AddRupees(int num_rupees)
    {
        rupee_count += num_rupees;
        UpdateRupeeCount();
    }
    public void UseRupees(int num_rupees = 1)
    {
        if (GameController.god_mode)
            return;
        rupee_count -= num_rupees;
        UpdateRupeeCount();
    }
    public int GetRupees()
    {
        if (GameController.god_mode)
            return 999;
        return rupee_count;
    }

    public void UpdateKeyCount()
    {
        keyDisplayText.text = "x" + GetKeys().ToString();
    }
    public void AddKeys(int amount = 1)
    {
        key_count += amount;
        UpdateKeyCount();
    }
    public void UseKeys(int amount = 1)
    {
        if (GameController.god_mode)
            return;
        key_count -= amount;
        UpdateKeyCount();
    }
    public int GetKeys()
    {
        if (GameController.god_mode)
            return 99;
        return key_count;
    }

    public void UpdateBombCount()
    {
        bombDisplayText.text = "x" + GetBombs().ToString();
    }
    public void AddBombs(int amount = 1)
    {
        bomb_count += amount;
        UpdateBombCount();
    }    
    public void UseBombs(int amount = 1)
    {
        if (GameController.god_mode)
            return;
        bomb_count -= amount;
        UpdateBombCount();
    }
    public int GetBombs()
    {
        if (GameController.god_mode)
            return 99;
        return bomb_count;
    }
}
