using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnsExplosion : MonoBehaviour
{
    [SerializeField] GameObject prefabSource;
    [SerializeField] float lifespan = 3.0f;
    [SerializeField] AudioClip spawnSound;
    [SerializeField] AudioClip fuseSound;

    private void Start()
    {
        AudioSource.PlayClipAtPoint(fuseSound, Camera.main.transform.position);
    }

    void Update()
    {
        if (lifespan > 0.0f)
        {
            lifespan -= Time.deltaTime;
        }
        else
        {
            GameObject clone = (GameObject) Instantiate(prefabSource, gameObject.transform.position, Quaternion.identity);
            AudioSource.PlayClipAtPoint(spawnSound, Camera.main.transform.position);
            Destroy(gameObject);
        }
    }
}
