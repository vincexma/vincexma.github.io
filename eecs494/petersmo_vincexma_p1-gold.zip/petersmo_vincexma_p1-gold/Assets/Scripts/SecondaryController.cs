using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SecondaryController : MonoBehaviour
{
    [SerializeField] Image BombIcon;
    [SerializeField] Image BowIcon;
    [SerializeField] Image BoomerangIcon;
    [SerializeField] Image BombermanIcon;

    [SerializeField] GameObject Bomb;
    [SerializeField] GameObject Bow;
    [SerializeField] GameObject Boomerang;
    [SerializeField] GameObject Bomberman;

    [SerializeField] int numTools = 3;
    int current = 2;

    public Component[] secondaries;

    private void Start()
    {
        enableTool(Bomb, BombIcon);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            while (true)
            {
                secondaries = GetComponentsInChildren<ActivatedByPlayerDirectionAndKeyDown>();
                current = (current + 1) % numTools;
                Debug.Log(current);
                if (current == 0)
                {

                    foreach (ActivatedByPlayerDirectionAndKeyDown secondary in secondaries)
                    {
                        if (GameController.god_mode || (secondary.unlocked && secondary.CompareTag("bow")))
                        {
                            disableTool(Bomb, BombIcon);
                            disableTool(Bomberman, BombermanIcon);
                            disableTool(Boomerang, BoomerangIcon);
                            enableTool(Bow, BowIcon);
                            return;
                        }
                    }

                    // current = (current + 1) % numTools;

                }
                else if (current == 1)
                {
                    foreach (ActivatedByPlayerDirectionAndKeyDown secondary in secondaries)
                    {
                        if (GameController.god_mode || (secondary.unlocked && secondary.CompareTag("boom")))
                        {
                            disableTool(Bomb, BombIcon);
                            disableTool(Bomberman, BombermanIcon);
                            disableTool(Bow, BowIcon);
                            enableTool(Boomerang, BoomerangIcon);
                            return;
                        }
                    }
                    // current = (current + 1) % numTools;
                }
                else if (current == 2)
                {
                    disableTool(Bomberman, BombermanIcon);
                    disableTool(Bow, BowIcon);
                    disableTool(Boomerang, BoomerangIcon);
                    enableTool(Bomb, BombIcon);
                    return;
                }
                else if (current == 3)
                {
                    foreach (ActivatedByPlayerDirectionAndKeyDown secondary in secondaries)
                    {
                        if (secondary.unlocked && secondary.CompareTag("bombman"))
                        {
                            disableTool(Bomb, BombIcon);
                            enableTool(Bomberman, BombermanIcon);
                            disableTool(Bow, BowIcon);
                            disableTool(Boomerang, BoomerangIcon);
                            return;
                        }
                    }
                    // current = (current + 1) % numTools;
                }
            }
        }
    }

    private void disableTool(GameObject obj, Image icon)
    {
        obj.GetComponent<ActivatedByPlayerDirectionAndKeyDown>().enabled = false;
        icon.enabled = false;
    }
    private void enableTool(GameObject obj, Image icon)
    {
        obj.GetComponent<ActivatedByPlayerDirectionAndKeyDown>().enabled = true;
        icon.enabled = true;
    }
}
